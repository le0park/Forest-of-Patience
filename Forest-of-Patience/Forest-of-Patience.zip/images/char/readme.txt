move, climb, stand ->50 * 70
lie -> 70 * 45